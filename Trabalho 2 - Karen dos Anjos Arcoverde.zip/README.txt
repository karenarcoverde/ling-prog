Este programa lê as linhas de texto de um arquivo *.txt e encontra as palavras mais utilizadas, assim como as sequências de de duas ou mais palavras consecutivas mais utilizadas.

Instruções sobre o Menu:
O usuário deverá escolher uma opção das citadas abaixo. Ele poderá escolher quantas vezes quiser as opções enquanto não for escolhida a opção 4 (Sair).

1. Mostrar a(s) palavra(s) mais utilizada(s) no texto
2. Mostrar a(s) sequencia(s) de palavras de comprimento 2 mais utilizada(s) no texto
3. Mostrar a(s) sequencia(s) de palavras de comprimento N mais utilizada(s) no texto
4. Sair

NECESSIDADES:
UTILIZAR UM ARQUIVO *.txt FEITO NO LINUX

Para compilar:
Digite make no terminal

Para executar:
./grafo 