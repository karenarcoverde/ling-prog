Este programa possui um catálogo de filmes que pode ser gerenciado por um usuário através do menu.

Instruções sobre o Menu:
O usuário deverá escolher uma opção das citadas abaixo. Ele poderá escolher quantas vezes quiser as opções enquanto não for escolhida a opção 7 (Sair).

1. Insere filme -> O usuário pode inserir o filme e no arquivo o filme aparecerá em ordem alfabética.
2. Remove filme -> O usuário poderá escolher um filme para remover.
3. Busca e exibe filme -> O usuário digita o nome do filme que deseja buscar e o filme é exibido na tela, com sua respectiva produtora e nota.
4. Editar filme -> O usuário deve digitar o nome do filme e posteriormente o que deseja mudar (produtora ou nota).
5. Exibir Catalogo -> Aparece na tela todo os filmes guardados no arquivo filmes.txt.
6. Exibir filme mais bem avaliado -> O filme com maior nota é exibido, caso tenha filmes com a mesma nota, os filmes com a mesma nota são exibidos na tela.
7. Sair -> O programa é finalizado e o catálogo atualizado.

Para compilar:
Digite make no terminal

Para executar:
./filmes